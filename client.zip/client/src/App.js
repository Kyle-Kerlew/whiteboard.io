import React from 'react';
import Router from "./components/routing/router";

function App() {
    return (
        <Router/>
    )
}

export default App;
